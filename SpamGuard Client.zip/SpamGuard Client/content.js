// ========================================================
// CONFIGURATION
// ========================================================
const API_URL = "https://spam-guard-api.onrender.com"; 

// 1. Get the Image URL
const logoUrl = chrome.runtime.getURL("logo.png");

// ========================================================
// UI CREATION
// ========================================================
const overlay = document.createElement("div");
overlay.id = "spam-guard-overlay";
overlay.className = "minimized";
// Initial Position (Bottom Right)
overlay.style.bottom = "30px";
overlay.style.right = "30px";

overlay.innerHTML = `
  <div id="sg-minimized-icon">
    <img src="${logoUrl}" style="width: 100%; height: 100%; object-fit: cover; pointer-events: none; border-radius: 50%;">
  </div>

  <div id="sg-expanded-view">
    <div class="sg-header" id="sg-drag-header">
      <div style="display: flex; align-items: center; pointer-events: none;">
        <span>🛡️ Spam Guard</span>
      </div>
      <div>
        <span id="sg-power" class="sg-power-btn" title="Turn Off Extension">OFF</span>
        <span id="sg-minimize" style="font-size: 18px; cursor: pointer;">−</span>
      </div>
    </div>
    <div class="sg-content">
      <div class="sg-verdict" id="sg-verdict">Waiting...</div>
      <div class="sg-bar-bg"><div class="sg-bar-fill" id="sg-bar"></div></div>
      <div class="sg-explanation" id="sg-explanation">Open an email to scan.</div>
    </div>
  </div>
`;
document.body.appendChild(overlay);

// ========================================================
// DRAG & DROP LOGIC
// ========================================================
let isDragging = false;
let hasMoved = false; 
let dragOffset = { x: 0, y: 0 };

const header = document.getElementById('sg-drag-header');
const minIcon = document.getElementById('sg-minimized-icon');

function startDrag(e) {
    if (e.button !== 0) return;
    if (e.target.id === 'sg-power' || e.target.id === 'sg-minimize') return;

    isDragging = true;
    hasMoved = false; 

    const rect = overlay.getBoundingClientRect();
    dragOffset.x = e.clientX - rect.left;
    dragOffset.y = e.clientY - rect.top;

    // Switch to absolute positioning
    overlay.style.bottom = 'auto';
    overlay.style.right = 'auto';
    overlay.style.left = rect.left + 'px';
    overlay.style.top = rect.top + 'px';

    document.addEventListener('mousemove', doDrag);
    document.addEventListener('mouseup', stopDrag);
    e.preventDefault(); 
}

function doDrag(e) {
    if (!isDragging) return;
    hasMoved = true; 

    let newX = e.clientX - dragOffset.x;
    let newY = e.clientY - dragOffset.y;

    // Keep it on screen while dragging
    const windowW = window.innerWidth;
    const windowH = window.innerHeight;
    const widgetW = overlay.offsetWidth;
    const widgetH = overlay.offsetHeight;

    if (newX < 0) newX = 0;
    if (newX + widgetW > windowW) newX = windowW - widgetW;
    if (newY < 0) newY = 0;
    if (newY + widgetH > windowH) newY = windowH - widgetH;

    overlay.style.left = newX + 'px';
    overlay.style.top = newY + 'px';
}

function stopDrag() {
    isDragging = false;
    document.removeEventListener('mousemove', doDrag);
    document.removeEventListener('mouseup', stopDrag);
}

header.addEventListener('mousedown', startDrag);
minIcon.addEventListener('mousedown', startDrag);

// ========================================================
// SMART BOUNDARY CHECK (NEW FIX!)
// ========================================================
function adjustPosition() {
    // Only adjust if the user has manually dragged it (using left/top)
    if (overlay.style.left && overlay.style.left !== "auto") {
        const winW = window.innerWidth;
        const winH = window.innerHeight;
        const expandedWidth = 320; // Matches CSS
        
        let currentLeft = parseFloat(overlay.style.left);
        let currentTop = parseFloat(overlay.style.top);

        // Check Horizontal: If expanding pushes it off-screen to the right
        if (currentLeft + expandedWidth > winW) {
            let newLeft = winW - expandedWidth - 20; // 20px padding
            overlay.style.left = Math.max(0, newLeft) + "px";
        }

        // Check Vertical: If it's too low at the bottom
        if (currentTop > winH - 200) {
            let newTop = winH - 300; 
            overlay.style.top = Math.max(0, newTop) + "px";
        }
    }
}

// ========================================================
// UI STATE LOGIC
// ========================================================

// MAXIMIZE (Clicking the minimized icon)
minIcon.addEventListener("click", (e) => {
    if (!hasMoved) {
        overlay.classList.remove("minimized");
        adjustPosition(); // <--- Run the check!
    }
});

// MINIMIZE
document.getElementById("sg-minimize").addEventListener("click", (e) => {
  e.stopPropagation(); 
  overlay.classList.add("minimized");
});

// TURN OFF
document.getElementById("sg-power").addEventListener("click", (e) => {
  e.stopPropagation(); 
  chrome.storage.local.set({ isActive: false });
  overlay.style.display = "none";
  alert("SpamGuard is OFF. Use the extension toolbar icon to turn it back ON.");
});

// Load State
chrome.storage.local.get("isActive", (data) => {
  if (data.isActive === false) overlay.style.display = "none";
});

// Toggle from Toolbar
chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "TOGGLE_WIDGET") {
    overlay.style.display = request.state ? "block" : "none";
  }
});

// ========================================================
// CORE LOGIC: DETECT EMAIL & SCAN
// ========================================================
let lastUrl = location.href;

new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    const isEmailOpen = /inbox\/[a-zA-Z0-9]+/.test(location.href) || /spam\/[a-zA-Z0-9]+/.test(location.href);

    chrome.storage.local.get("isActive", (data) => {
      if (isEmailOpen && data.isActive !== false) {
        overlay.classList.remove("minimized");
        adjustPosition(); // <--- Run the check here too!
        
        updateUI("Scanning...", "gray", 0, "Analyzing content and sender...");
        setTimeout(scanEmail, 1000);
      }
    });
  }
}).observe(document, { subtree: true, childList: true });

async function scanEmail() {
  const emailBodyNode = document.querySelector('.a3s');
  const subjectNode = document.querySelector('h2[data-thread-perm-id]');
  const senderNode = document.querySelector('span.gD');
  const senderEmail = senderNode ? senderNode.getAttribute("email") : "Unknown Sender";
  const isSpamFolder = window.location.href.includes("#spam") || window.location.href.includes("/spam/");

  if (!emailBodyNode) return;

  const bodyText = emailBodyNode.innerText;
  const subjectText = subjectNode ? subjectNode.innerText : "No Subject";

  try {
    const response = await fetch(`${API_URL}/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subject: subjectText,
        body: bodyText,
        sender: senderEmail
      })
    });
    const data = await response.json();

    if (data.verdict === "SPAM") {
      updateUI("⚠️ SPAM DETECTED", "red", data.confidence_score, data.explanation);
    } else if (isSpamFolder && data.verdict === "SAFE") {
        updateUI("⚠️ GOOGLE MARKED SPAM", "orange", 50, `Our AI thinks this looks safe, but Google marked it as Spam. Be careful.`);
    } else {
      updateUI("✅ LOOKS SAFE", "green", data.confidence_score, data.explanation);
    }

  } catch (error) {
    console.error(error);
    updateUI("Connection Error", "orange", 0, "Check backend or internet.");
  }
}

function updateUI(text, colorClass, confidence, explanation) {
  const verdictEl = document.getElementById("sg-verdict");
  const barEl = document.getElementById("sg-bar");
  const expEl = document.getElementById("sg-explanation");

  verdictEl.className = "sg-verdict";
  barEl.className = "sg-bar-fill";
  verdictEl.innerText = text;
  verdictEl.classList.add(`text-${colorClass}`);
  barEl.style.width = `${confidence}%`;
  barEl.classList.add(`bg-${colorClass}`);
  expEl.innerText = explanation;
}